import 'package:btcclient/core/config/theme.dart';
import 'package:btcclient/core/layout/dashboard_layout.dart';
import 'package:btcclient/core/screens/join_community.dart';
import 'package:btcclient/core/widgets/navbar/side_drawer.dart';
import 'package:btcclient/core/widgets/navbar/sidebar_item.dart';
import 'package:btcclient/features/auth/presentation/provider/auth_notifier.dart';
import 'package:btcclient/features/confirmation/presentation/screen/confirmation_page.dart';
import 'package:btcclient/features/guardian/presentation/screens/guardian_dashboard.dart';
import 'package:btcclient/features/guardian/presentation/screens/guardian_payment_screen.dart';
import 'package:btcclient/features/guardian/presentation/screens/how_it_works_screen.dart';
import 'package:btcclient/features/hire_tutor/presentation/screen/post_job_page.dart';
import 'package:btcclient/features/invoices/presentation/screen/invoice_page.dart';
import 'package:btcclient/features/jobs/presentation/screen/job_page.dart';
import 'package:btcclient/features/legal/data/guardian_important_guidelines_data.dart';
import 'package:btcclient/features/legal/presentation/important_guidelines_screen.dart';
import 'package:btcclient/core/screens/share_app.dart';
import 'package:btcclient/features/profile/presentation/screens/guardian_profile_page.dart';
import 'package:btcclient/features/settings/prersentation/screens/setting_screen.dart';
import 'package:btcclient/features/settings/prersentation/widgets/show_logout_dialog%20copy.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';

class GuardianDashboardScreen extends ConsumerWidget {
  const GuardianDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider).user;

    if (user == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return DashboardLayout(
      role: "guardian",
      initialIndex: 2,
      pageTitles: const ["My Jobs", "Hire a Tutor", "Dashboard", "Payment"],
      drawerBuilder: (changeTab) => AppSidebar(
        user: user,

        menuItems: [
          SidebarItem(
            label: "Dashboard",
            icon: SvgPicture.asset(
              "assets/icons/navigations/dashboard-square.svg",
              width: 20,
              height: 20,
              colorFilter: const ColorFilter.mode(
                Colors.white,
                BlendMode.srcIn,
              ),
            ),
            onTap: () {
              Navigator.pop(context);
              changeTab(2);
            },
          ),
          SidebarItem(
            label: "Posted Jobs",
            icon: SvgPicture.asset(
              "assets/icons/navigations/job-board.svg",
              width: 20,
              height: 20,
              colorFilter: const ColorFilter.mode(
                Colors.white,
                BlendMode.srcIn,
              ),
            ),
            onTap: () {
              Navigator.pop(context);
              changeTab(0);
            },
          ),
          SidebarItem(
            label: "Hair a tutor",
            icon: SvgPicture.asset(
              "assets/icons/navigations/job-search.svg",
              width: 20,
              height: 20,
              colorFilter: const ColorFilter.mode(
                Colors.white,
                BlendMode.srcIn,
              ),
            ),
            onTap: () {
              Navigator.pop(context);
              changeTab(3);
            },
          ),
          SidebarItem(
            label: "Confirmation Letter",
            icon: SvgPicture.asset(
              "assets/icons/navigations/confirmed.svg",
              width: 20,
              height: 20,
              colorFilter: const ColorFilter.mode(
                Colors.white,
                BlendMode.srcIn,
              ),
            ),
            onTap: () {
              Navigator.pop(context);

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const ConfirmationScreen(role: "guardian"),
                ),
              );
            },
          ),
          SidebarItem(
            label: "How it Works",
            icon: SvgPicture.asset(
              "assets/icons/navigations/how-it-works.svg",
              width: 20,
              height: 20,
              colorFilter: const ColorFilter.mode(
                Colors.white,
                BlendMode.srcIn,
              ),
            ),
            onTap: () {
              Navigator.pop(context); // closes drawer

              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HowItWorksScreen()),
              );
            },
          ),
          SidebarItem(
            label: "Profile",
            icon: SvgPicture.asset(
              "assets/icons/navigations/user-circle.svg",
              width: 20,
              height: 20,
              colorFilter: const ColorFilter.mode(
                Colors.white,
                BlendMode.srcIn,
              ),
            ),
            onTap: () {
              Navigator.pop(context);
              changeTab(4);
            },
          ),

          SidebarItem(
            label: "Payments",
            icon: SvgPicture.asset(
              "assets/icons/navigations/payment.svg",
              width: 20,
              height: 20,
              colorFilter: const ColorFilter.mode(
                Colors.white,
                BlendMode.srcIn,
              ),
            ),
            onTap: () {
              Navigator.pop(context); // closes drawer
              
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => GuardianPaymentScreen(),
                ),
              );
            },
          ),
          SidebarItem(
            label: "Invoices",
            icon: SvgPicture.asset(
              "assets/icons/navigations/invoice.svg",
              width: 20,
              height: 20,
              colorFilter: const ColorFilter.mode(
                Colors.white,
                BlendMode.srcIn,
              ),
            ),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const InvoiceScreen(role: "guardian"),
                ),
              );
            },
          ),
          SidebarItem(
            label: "Settings",
            icon: SvgPicture.asset(
              "assets/icons/navigations/settings.svg",
              width: 20,
              height: 20,
              colorFilter: const ColorFilter.mode(
                Colors.white,
                BlendMode.srcIn,
              ),
            ),
             onTap: () {
              Navigator.pop(context);
              changeTab(3);
            },
            
          ),
        ],

        /// sidebar extra links
        menuItemsCommon: [
          SidebarItem(
            label: "Share The App",
            icon: SvgPicture.asset(
              "assets/icons/navigations/share.svg",
              width: 20,
              height: 20,
              colorFilter: const ColorFilter.mode(
                Colors.white,
                BlendMode.srcIn,
              ),
            ),
            onTap: () {
              Navigator.pop(context); // closes drawer

              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ShareScreen()),
              );
            },
          ),
          SidebarItem(
            label: "Join Community",
            icon: SvgPicture.asset(
              "assets/icons/social_media/facebook.svg",
              width: 20,
              height: 20,
              colorFilter: const ColorFilter.mode(
                Colors.white,
                BlendMode.srcIn,
              ),
            ),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const CommunityPage(
                    title: "Guardian Community",
                    description:
                        "Join the Guardian Community to share your feedback, stay connected with our team and receive important updates and expert guidance to support your child’s learning.",
                    buttonText: "Join Community",
                    link: "https://www.facebook.com/groups/248374924778212",
                  ),
                ),
              );
            },
          ),
          SidebarItem(
            label: "Important Guideline",
            icon: SvgPicture.asset(
              "assets/icons/navigations/question-mark.svg",
              width: 20,
              height: 20,
              colorFilter: const ColorFilter.mode(
                Colors.white,
                BlendMode.srcIn,
              ),
            ),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ImportantGuidelinesScreen(
                    document: guardianImportantGuidelinesData,
                  ),
                ),
              );
            },
          ),
        ],

        onLogout: () async {
          showLogoutDialog(context);
        },
      ),

      pages: [
        (changeTab, status) => JobsPage(
          changeTab: changeTab,
          role: "guardian",
          initialStatus: status, // 🔥 IMPORTANT
        ),

        (changeTab, status) => PostJobPage(changeTab: changeTab),

        (changeTab, status) => GuardianHomeScreen(
          changeTab: changeTab, // 🔥 PASS IT
        ),

        (changeTab, status) => SettingScreen(changeTab: changeTab),
        (changeTab, status) => GuardianProfilePage(changeTab: changeTab),
      ],

      navItems: [
        BottomNavigationBarItem(
          icon: SvgPicture.asset(
            "assets/icons/navigations/posting.svg",
            width: 22,
            height: 22,
            colorFilter: const ColorFilter.mode(
              AppColors.neutrals06,
              BlendMode.srcIn,
            ),
          ),
          activeIcon: SvgPicture.asset(
            "assets/icons/navigations/posting.svg",
            width: 22,
            height: 22,
            colorFilter: ColorFilter.mode(AppColors.primary01, BlendMode.srcIn),
          ),
          label: "My Jobs",
        ),

        BottomNavigationBarItem(
          icon: SvgPicture.asset(
            "assets/icons/navigations/job-search.svg",
            width: 22,
            height: 22,
            colorFilter: const ColorFilter.mode(
              AppColors.neutrals06,
              BlendMode.srcIn,
            ),
          ),
          activeIcon: SvgPicture.asset(
            "assets/icons/navigations/job-search.svg",
            width: 22,
            height: 22,
            colorFilter: ColorFilter.mode(AppColors.primary01, BlendMode.srcIn),
          ),
          label: "Hire Tutor",
        ),

        /// CENTER HOME
        BottomNavigationBarItem(
          icon: SvgPicture.asset(
            "assets/icons/navigations/dashboard-square.svg",
            width: 26,
            height: 26,
            colorFilter: const ColorFilter.mode(
              AppColors.neutrals06,
              BlendMode.srcIn,
            ),
          ),
          activeIcon: SvgPicture.asset(
            "assets/icons/navigations/dashboard-square.svg",
            width: 26,
            height: 26,
            colorFilter: ColorFilter.mode(AppColors.primary01, BlendMode.srcIn),
          ),
          label: "Dashboard",
        ),

        BottomNavigationBarItem(
          icon: SvgPicture.asset(
            "assets/icons/navigations/settings.svg",
            width: 22,
            height: 22,
            colorFilter: const ColorFilter.mode(
              AppColors.neutrals06,
              BlendMode.srcIn,
            ),
          ),
          activeIcon: SvgPicture.asset(
            "assets/icons/navigations/settings.svg",
            width: 22,
            height: 22,
            colorFilter: ColorFilter.mode(AppColors.primary01, BlendMode.srcIn),
          ),
          label: "Settings",
        ),

        BottomNavigationBarItem(
          icon: SvgPicture.asset(
            "assets/icons/navigations/user-circle.svg",
            width: 22,
            height: 22,
            colorFilter: const ColorFilter.mode(
              AppColors.neutrals06,
              BlendMode.srcIn,
            ),
          ),
          activeIcon: SvgPicture.asset(
            "assets/icons/navigations/user-circle.svg",
            width: 22,
            height: 22,
            colorFilter: ColorFilter.mode(AppColors.primary01, BlendMode.srcIn),
          ),
          label: "Profile",
        ),
      ],
    );
  }
}
