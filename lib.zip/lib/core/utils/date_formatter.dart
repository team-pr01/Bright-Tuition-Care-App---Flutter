import 'package:intl/intl.dart';

class DateFormatter {

  static String formatSince(String date) {
    try {
      final parsed = DateTime.parse(date);
      return DateFormat('MMM yyyy').format(parsed);
    } catch (e) {
      return date;
    }
  }
  static String formatSinceFullDate(String date) {
  try {
    final parsed = DateTime.parse(date);
    return DateFormat('MMMM d, yyyy').format(parsed);
  } catch (e) {
    return date;
  }
}
  static String formattedDate(String date) {
    try {
      final parsed = DateTime.parse(date);
      return DateFormat('dd MMM yyyy').format(parsed);
    } catch (e) {
      return date;
    }
  }
  static String formattedFormalDate(String date) {
  try {
    final parsed = DateTime.parse(date);
    return DateFormat('dd/MM/yyyy').format(parsed);
  } catch (e) {
    return date;
  }
}

}